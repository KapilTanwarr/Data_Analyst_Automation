
def summarize_data(df):
    return df.describe(include='all')
